# Telethon Bot (Pydroid3 uchun)

📌 Ushbu bot sizning Telegram profilingizga ulanadi va test uchun o'zingizga xabar yuboradi.

## O'rnatish
```bash
pkg install git
pip install -r requirements.txt