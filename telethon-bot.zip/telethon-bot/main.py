from telethon import TelegramClient

# 🔑 My.telegram.org dan olingan ma'lumotlaringiz
api_id = 22390550
api_hash = "69d7e30c35fc08a6e4ff3687062884aa"

# Sessiya fayli (telefoningizda yoki serverda saqlanadi)
client = TelegramClient("session", api_id, api_hash)

async def main():
    # Profil ma'lumotlarini chiqarish
    me = await client.get_me()
    print("✅ Tizimga kirdingiz:", me.first_name)

    # Test uchun o'zingizga xabar yuborish
    await client.send_message("me", "Salom! Kod ishladi ✅")

with client:
    client.loop.run_until_complete(main())